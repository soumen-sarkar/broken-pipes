jQuery(window).load(function(){
	//Background Image carousel
	$('.testimonialSlider').carousel({
		interval: 15000
	})	 
	//Script of equal height
	$(function(cash) {
		$('.equal').responsiveEqualHeightGrid(); 
	});
	$(function(cash) {
		$('.equalTwo').responsiveEqualHeightGrid(); 
	});	
});